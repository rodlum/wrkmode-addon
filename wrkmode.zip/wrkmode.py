bl_info = {
    "name": "WrkMode",
    "author": "rod lumampao",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Panel",
    "description": "manipulate Objects",
    "warning": "",
    "doc_url": "",
    "category": "object mesh",
}    

import bpy
from bpy.ops import Operator

class ShearPanel(bpy.types.Panel):
    bl_label = "Shear Mode"
    bl_idname = "OBJECT_PT_shear_mode"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "wrkmode"

    def draw(self, context):
        layout = self.layout
        layout.operator("transform.shear")
        row = layout.row()
        row.operator("view3d.switch_to_front_view", text="Switch to Front View")

class SwitchToFrontViewOperator(bpy.types.Operator):
    """Switch to Front View"""
    bl_idname = "view3d.switch_to_front_view"
    bl_label = "Switch to Front View"

    def execute(self, context):
        bpy.ops.view3d.view_axis(type='FRONT')
        return {'FINISHED'}

# Create a new panel
class RotationPanel(bpy.types.Panel):
    """A panel for rotating objects"""
    bl_label = "Rotation Panel"
    bl_idname = "OBJECT_PT_rotation"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "wrkmode"

    # Add a button to the panel that rotates the active object 90 degrees around the x axis
    def draw(self, context):
        layout = self.layout      
        self.layout.operator("object.rotate_x", icon ="CON_CLAMPTO")
        row = layout.row()
        props =  self.layout.operator("object.rotate_y", icon ="CON_CLAMPTO")
        row = layout.row()
        props =  self.layout.operator("object.rotate_z", icon ="CON_CLAMPTO")

# Define a function to be called when the button is clicked
def rotate_x(self, context):
    # Get the active object
    obj = bpy.context.active_object

    # Rotate the object 90 degrees around the x axis
    obj.rotation_euler.x += 1.5708

    # Update the 3D view
    context.area.tag_redraw()

# Create a new operator for rotating the object
class RotateXOperator(bpy.types.Operator):
    """Rotate the active object 90 degrees around the x axis"""
    bl_idname = "object.rotate_x"
    bl_label = "Rotate X 90"

    # Set the function to be called when the operator is executed
    def execute(self, context):
        rotate_x(self, context)
        return {'FINISHED'}

# Define a function to be called when the button is clicked
def rotate_y(self, context):
    # Get the active object
    obj = bpy.context.active_object

    # Rotate the object 90 degrees around the y axis
    obj.rotation_euler.y += 1.5708

    # Update the 3D view
    context.area.tag_redraw()

# Create a new operator for rotating the object
class RotateYOperator(bpy.types.Operator):
    """Rotate the active object 90 degrees around the y axis"""
    bl_idname = "object.rotate_y"
    bl_label = "Rotate Y 90"

    # Set the function to be called when the operator is executed
    def execute(self, context):
        rotate_y(self, context)
        return {'FINISHED'}
    
    # Define a function to be called when the button is clicked
def rotate_z(self, context):
    # Get the active object
    obj = bpy.context.active_object

    # Rotate the object 90 degrees around the z axis
    obj.rotation_euler.z += 1.5708

    # Update the 3D view
    context.area.tag_redraw()

# Create a new operator for rotating the object
class RotateZOperator(bpy.types.Operator):
    """Rotate the active object 90 degrees around the z axis"""
    bl_idname = "object.rotate_z"
    bl_label = "Rotate Z 90"

    # Set the function to be called when the operator is executed
    def execute(self, context):
        rotate_z(self, context)
        return {'FINISHED'}
    
 # the Transfer operator is executed

class TransferPanel(bpy.types.Panel):
    bl_label = "Transfer Edit/Sculpt mode"
    bl_idname = "OBJECT_PT_transfer_mode"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "wrkmode"

    def draw(self, context):
        layout = self.layout
        obj = context.object

        layout.prop(obj, "transfer_mode", text="Mode")
        layout.prop(obj, "transfer_keep_vertex_order", text="Keep Vertex Order")
        layout.operator("object.transfer_mode", icon ="GROUP_BONE")
        
class OBJECT_PT_OriginPanel(bpy.types.Panel):
    """A custom panel for setting the origin of an object to the median of its geometry"""
    bl_label = "Origin RESET"
    bl_idname = "OBJECT_PT_origin_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator("object.origin_set", text="Origin to OBJECT").type = 'ORIGIN_GEOMETRY'
        row = layout.row()
        row.operator("object.origin_set", text="Clear").type = 'ORIGIN_GEOMETRY'
        row = layout.row()
        row.operator("object.origin_set", text="Origin to CURSOR").type = 'ORIGIN_CURSOR'
        row = layout.row()
        row.operator("object.origin_set", text="OBJECT to Origin").type = 'GEOMETRY_ORIGIN'
        
# Register the panel and operator with Blender       
def register():
    bpy.utils.register_class(ShearPanel)
    bpy.utils.register_class(SwitchToFrontViewOperator)
    bpy.utils.register_class(RotationPanel)
    bpy.utils.register_class(RotateXOperator)
    bpy.utils.register_class(RotateYOperator)
    bpy.utils.register_class(RotateZOperator)
    bpy.utils.register_class(TransferPanel)
    bpy.utils.register_class(OBJECT_PT_OriginPanel)
     
def unregister():
    bpy.utils.unregister_class(ShearPanel)
    bpy.utils.unregister_class(SwitchToFrontViewOperator)
    bpy.utils.unregister_class(RotationPanel)
    bpy.utils.unregister_class(RotateXOperator)
    bpy.utils.unregister_class(RotateYOperator)
    bpy.utils.unregister_class(RotateZOperator)
    bpy.utils.unregister_class(TransferPanel)
    bpy.utils.unregister_class(OBJECT_PT_OriginPanel)
    
if __name__ == "__main__":
    register()